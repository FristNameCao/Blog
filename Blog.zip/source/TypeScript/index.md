---
title: TypeScript
date: 2023-02-11 23:52:13
---

# typescript思维导图

![typescript](https://fristnamecao.github.io/img/typescript.jpg)