---
title: CSS_
date: 2023-02-11 22:23:32

---





## 1.flex思维导图:

+ 1.2该flex思维针对于flex编写



![flex](https://fristnamecao.github.io/img/flex.jpg)





## 2.CSS布局属性:

+ 2.1该图总结了布局的各种属性

![布局属性](https://fristnamecao.github.io/img/布局属性.png)

## 3.CSS选择器：

+ 3.1改图总结了各种选择器方便查看

![选择器](https://fristnamecao.github.io/img/选择器.png)

## 4.CSS样式属性(含动画):

+ 4.1该图总结了各种样式调试

![样式属性](https://fristnamecao.github.io/img/样式属性.png)

## 5.CSS最终总结:



+ 5.1该图总结了CSS所有属性和布局

![总结](https://fristnamecao.github.io/img/总结.png)


