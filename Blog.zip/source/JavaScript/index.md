---
title: JavaScript
date: 2023-02-12 13:43:32
---



# 个人搜集一些jsAPI思维导图

## Array数组思维导图:

![数组](https://fristnamecao.github.io/img/数组/031426347503011.gif)





## BOM思维导图:

![BOM](https://fristnamecao.github.io/img/BOM/291311256619962.jpg)

## DOM思维导图:

## 1.1



![DOM](https://fristnamecao.github.io/img/DOM/031430098606493.gif)



## 1.2

![DOM](https://fristnamecao.github.io/img/DOM/291310116771993.jpg)



## JS正则表达式:

![正则](https://fristnamecao.github.io/img/正则/031430427829068.gif)